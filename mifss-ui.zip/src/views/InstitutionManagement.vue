<template>
  <div class="institution-management">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>机构管理</span>
          <el-button type="primary" @click="handleAdd">新增机构</el-button>
        </div>
      </template>

      <!-- 搜索区域 -->
      <el-form :inline="true" :model="searchForm" class="search-form">
        <el-form-item label="机构名称">
          <el-input v-model="searchForm.medinsName" placeholder="请输入机构名称" clearable />
        </el-form-item>
        <el-form-item label="机构编码">
          <el-input v-model="searchForm.medinsCode" placeholder="请输入机构编码" clearable />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">查询</el-button>
          <el-button @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>

      <!-- 表格 -->
      <el-table :data="tableData" border stripe v-loading="loading">
        <el-table-column type="index" label="序号" width="60" />
        <el-table-column prop="medinsName" label="机构名称" min-width="150" />
        <el-table-column prop="medinsCode" label="机构编码" width="120" />
        <el-table-column prop="medinsMajcode" label="机构主编码" width="120" />
        <el-table-column prop="medinsTypeCode" label="机构类型编码" width="120" />
        <el-table-column prop="medinsNatu" label="机构性质" width="100" />
        <el-table-column prop="adminDiv" label="行政区划" width="100" />
        <el-table-column prop="crteTime" label="创建时间" width="160" />
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" size="small" @click="handleEdit(row)">编辑</el-button>
            <el-button type="danger" size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 数据总数 -->
      <div class="data-total">
        共 {{ pagination.total }} 条数据
      </div>
    </el-card>

    <!-- 新增/编辑对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogTitle"
      width="600px"
      @close="handleDialogClose"
    >
      <el-form :model="formData" :rules="rules" ref="formRef" label-width="120px">
        <el-form-item label="机构名称" prop="medinsName">
          <el-input v-model="formData.medinsName" placeholder="请输入机构名称" />
        </el-form-item>
        <el-form-item label="机构编码" prop="medinsCode">
          <el-input v-model="formData.medinsCode" placeholder="请输入机构编码" />
        </el-form-item>
        <el-form-item label="机构主编码" prop="medinsMajcode">
          <el-input v-model="formData.medinsMajcode" placeholder="请输入机构主编码" />
        </el-form-item>
        <el-form-item label="机构类型编码" prop="medinsTypeCode">
          <el-input v-model="formData.medinsTypeCode" placeholder="请输入机构类型编码" />
        </el-form-item>
        <el-form-item label="机构性质" prop="medinsNatu">
          <el-input v-model="formData.medinsNatu" placeholder="请输入机构性质" />
        </el-form-item>
        <el-form-item label="行政区划" prop="adminDiv">
          <el-input v-model="formData.adminDiv" placeholder="请输入行政区划" />
        </el-form-item>
        <el-form-item label="列表" prop="list">
          <el-input v-model="formData.list" placeholder="请输入列表" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getInstitutionList, addInstitution, updateInstitution, deleteInstitution } from '@/api/institution'

const loading = ref(false)
const tableData = ref([])
const dialogVisible = ref(false)
const dialogTitle = ref('新增机构')
const formRef = ref(null)
const isEdit = ref(false)

const searchForm = reactive({
  medinsName: '',
  medinsCode: ''
})

const pagination = reactive({
  total: 0
})

const formData = reactive({
  id: null,
  medinsName: '',
  medinsCode: '',
  medinsMajcode: '',
  medinsTypeCode: '',
  medinsNatu: '',
  adminDiv: '',
  list: ''
})

const rules = {
  medinsName: [{ required: true, message: '请输入机构名称', trigger: 'blur' }],
  medinsCode: [{ required: true, message: '请输入机构编码', trigger: 'blur' }]
}

// 获取列表数据
const fetchData = async () => {
  loading.value = true
  try {
    const data = {
      medinsName: searchForm.medinsName || '',
      medinsCode: searchForm.medinsCode || ''
    }
    const res = await getInstitutionList(data)
    tableData.value = res || []
    pagination.total = tableData.value.length
  } catch (error) {
    ElMessage.error('获取数据失败')
  } finally {
    loading.value = false
  }
}

// 搜索
const handleSearch = () => {
  fetchData()
}

// 重置
const handleReset = () => {
  searchForm.medinsName = ''
  searchForm.medinsCode = ''
  fetchData()
}

// 新增
const handleAdd = () => {
  isEdit.value = false
  dialogTitle.value = '新增机构'
  dialogVisible.value = true
}

// 编辑
const handleEdit = (row) => {
  isEdit.value = true
  dialogTitle.value = '编辑机构'
  Object.assign(formData, row)
  dialogVisible.value = true
}

// 删除
const handleDelete = (row) => {
  ElMessageBox.confirm('确定要删除该机构吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(async () => {
    try {
      await deleteInstitution({ medinsCode: row.medinsCode })
      ElMessage.success('删除成功')
      fetchData()
    } catch (error) {
      ElMessage.error('删除失败')
    }
  })
}

// 提交表单
const handleSubmit = async () => {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (valid) {
      try {
        if (isEdit.value) {
          await updateInstitution(formData)
          ElMessage.success('更新成功')
        } else {
          await addInstitution(formData)
          ElMessage.success('新增成功')
        }
        dialogVisible.value = false
        fetchData()
      } catch (error) {
        ElMessage.error(isEdit.value ? '更新失败' : '新增失败')
      }
    }
  })
}

// 关闭对话框
const handleDialogClose = () => {
  formRef.value?.resetFields()
  Object.keys(formData).forEach(key => {
    formData[key] = key === 'id' ? null : ''
  })
}

onMounted(() => {
  fetchData()
})
</script>

<style scoped>
.institution-management {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.search-form {
  margin-bottom: 20px;
}

.data-total {
  margin-top: 20px;
  text-align: right;
  color: #606266;
  font-size: 14px;
}
</style>
