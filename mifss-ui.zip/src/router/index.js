import { createRouter, createWebHistory } from 'vue-router'
import InstitutionManagement from '../views/InstitutionManagement.vue'
import Mainhilist from '../views/Mainhilist.vue'

const router = createRouter({
  history: createWebHistory('/mifss-ui'),
  routes: [
    {
      path: '/',
      redirect: '/mainhilist'
    },
    {
      path: '/institution',
      name: 'institution',
      component: InstitutionManagement
    },
    {
      path: '/mainhilist',
      name: 'mainhilist',
      component: Mainhilist
    }
  ]
})

export default router
