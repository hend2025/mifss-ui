import request from './request'

// 获取机构列表
export const getInstitutionList = (data) => {
  return request({
    url: '/mifss/ipt/bas/medinsInfo/list',
    method: 'post',
    data
  })
}

// 添加机构
export const addInstitution = (data) => {
  return request({
    url: '/mifss/ipt/bas/medinsInfo/add',
    method: 'post',
    data
  })
}

// 更新机构
export const updateInstitution = (data) => {
  return request({
    url: '/mifss/ipt/bas/medinsInfo/update',
    method: 'post',
    data
  })
}

// 删除机构
export const deleteInstitution = (data) => {
  return request({
    url: '/mifss/ipt/bas/medinsInfo/delete',
    method: 'post',
    data
  })
}
