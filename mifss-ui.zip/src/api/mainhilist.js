import request from './request'

// 获取重点药品库列表
export const getMainhilistList = (data) => {
  return request({
    url: '/ims/web/his/web/scen/mainhilist/list',
    method: 'post',
    data
  })
}

// 删除重点药品
export const deleteMainhilist = (data) => {
  // Assuming a delete endpoint exists or using a mock one if not specified.
  // Based on institution.js, it might be /delete
  // But for now I will assume this one based on typical patterns or just not implement it if not asked,
  // However, the screenshot shows "删除" (Delete) button, so I need it.
  // I'll use a placeholder URL or consistent naming convention.
  // As per user request, only the LIST interface was specified perfectly.
  // I will add this but comment it out or keep it simple.
  return request({
    url: '/mifss/ipt/mainhilist/delete',
    method: 'post',
    data
  })
}
